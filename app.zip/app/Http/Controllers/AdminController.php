<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Admin;

class AdminController extends Controller
{
    // ─── Show Login Page ─────────────────────────────────────────────────────
    public function login()
    {
        // If already logged in, redirect to admin page
        if (session()->has('admin_logged_in')) {
            return redirect('/admin-page');
        }

        return view('admin.login');
    }

    // ─── Handle Login POST ────────────────────────────────────────────────────
    public function doLogin(Request $request)
    {
        $request->validate([
            'username' => 'required|string',
            'password' => 'required|string',
        ]);

        $admin = Admin::where('username', $request->username)->first();

        if ($admin && $admin->verifyPassword($request->password)) {
            session([
                'admin_logged_in' => true,
                'admin_id'        => $admin->admin_id,
                'admin_name'      => $admin->name,
                'admin_username'  => $admin->username,
                'admin_role'      => $admin->role,
            ]);

            return redirect('/admin-page')->with('success', 'Welcome back, ' . $admin->name . '!');
        }

        return back()->withErrors([
            'username' => 'Invalid username or password.',
        ])->withInput(['username' => $request->username]);
    }

    // ─── Logout ───────────────────────────────────────────────────────────────
    public function logout(Request $request)
    {
        $request->session()->forget([
            'admin_logged_in',
            'admin_id',
            'admin_name',
            'admin_username',
            'admin_role',
        ]);

        return redirect('/login')->with('status', 'You have been logged out.');
    }

    // ─── Protected: Admin Dashboard ───────────────────────────────────────────
    public function index()
    {
        if (!session()->has('admin_logged_in')) {
            return redirect('/login')->with('status', 'Please login to continue.');
        }

        return view('admin.index');
    }

    // ─── Protected: Tasks ─────────────────────────────────────────────────────
    public function tasks()
    {
        if (!session()->has('admin_logged_in')) {
            return redirect('/login')->with('status', 'Please login to continue.');
        }

        return view('admin.tasks');
    }
}
